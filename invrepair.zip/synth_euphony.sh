/experiment/euphony/bin/run_with_new_phog $1 $2 2> tmp | tail -1
head -1 tmp
