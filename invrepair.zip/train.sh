/experiment/euphony/bin/run_phog_learner $1 $2 2> tmp1
head -1 tmp
